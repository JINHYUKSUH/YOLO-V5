# Casting > 2024-04-29 2:47pm
https://universe.roboflow.com/inha/casting-qfnbf

Provided by a Roboflow user
License: CC BY 4.0

